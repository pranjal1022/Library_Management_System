from tkinter import *
import time as tm
import sqlite3
from tkinter import messagebox
from datetime import timedelta,date,datetime


def student(name, id):
    global student_screen
    student_screen = Tk()
    student_screen.geometry("500x300")
    student_screen.title("Library Management system")
    student_screen.configure(bg='green')
    label1 = Label(student_screen, text="Librarian Name :   " + name)
    label1.grid(row=1,column=1,padx=10,pady=10)
    label2 = Label(student_screen, text="Librarian Id Number :    " + id)
    label2.grid(row=2,column=1,padx=10,pady=10)
    current_time = tm.strftime("%H:%M:%S")
    clockLabel = Label(student_screen, text="Login time :" + current_time)
    clockLabel.grid(row=1,column=4,padx=10,pady=10)

    btnissue = Button(student_screen, text="Issue Book", width=20, command=add)
    btnreturn = Button(student_screen, text="Return Book", width=20, command=return1)
    btnlogout1 = Button(student_screen, text="Logout", width=20, command=lambda: student_screen.destroy())
    btnquery = Button(student_screen,text="Show Records",width=20,command=query)

    btnissue.grid(row=3,column=3,padx=10,pady=10)
    btnreturn.grid(row=4,column=3,padx=10,pady=10)
    btnlogout1.grid(row=6,column=3,padx=10,pady=10)
    btnquery.grid(row=5,column=3,padx=10,pady=10)
    student_screen.mainloop



def add():
    global Name
    global Id
    global idate
    global rdate

    def IssueNow():

        conn = sqlite3.connect('library.db')
        c = conn.cursor()

        conn.commit()

        '''c.execute("""CREATE TABLE issue
        ( Name text,
          Id text,
          idate Int,
          rdate Int)
        """)
        '''
        #Insert into table
        c.execute("INSERT INTO issue VALUES (:Name,:Id,:Book,:Issue_date,:Return_date)",
        {
            'Name': Name.get(),
            'Id': Id.get(),
            'Book': book_selected.get(),
            'Issue_date': formatted_date,
            'Return_date': return_date

        })
        conn.commit()

        conn.close()

        messagebox.showinfo("Records", "Book Issued")



    global issue_screen
    issue_screen = Tk()
    issue_screen.geometry("600x400")
    issue_screen.title("Book Now")
    issue_screen.configure(bg='black')

    NameOfStudent = Label(issue_screen, text="Name Of Student :")
    NameOfStudent.grid(row=1,column=1,padx=10,pady=10)
    Name = Entry(issue_screen)
    Name.grid(row=1,column=2,padx=10,pady=10)

    IdNoOfStudent = Label(issue_screen, text="Library Id No :")
    IdNoOfStudent.grid(row=2,column=1,padx=10,pady=10)
    Id = Entry(issue_screen)
    Id.grid(row=2,column=2,padx=10,pady=10)

    today = date.today()
    formatted_date= today.strftime('%Y-%m-%d')
    IssueDate = Label(issue_screen, text="Issue Date :",)
    IssueDate.grid(row=3,column=1,padx=10,pady=10)
    idate = Label(issue_screen,text=today)
    idate.grid(row=3,column=2,padx=10,pady=10)

    Enddate= date.today() + timedelta(days=15)
    return_date=Enddate.strftime('%Y-%m-%d')
    ReturnDate = Label(issue_screen, text="Return Date :  ")
    ReturnDate.grid(row=4,column=1,padx=10,pady=10)
    rdate = Label(issue_screen,text=Enddate)
    rdate.grid(row=4,column=2,padx=10,pady=10)

    book_selected = StringVar()
    book2=Label(issue_screen,text="Choose Book")
    book2.grid(row=1,column=4,padx=10,pady=10)
    book1 = Radiobutton(issue_screen, text="Harry Potter", value="Harry Potter",variable=book_selected)
    book1.grid(row=2,column=4,padx=10,pady=10)
    book1 = Radiobutton(issue_screen, text="Tenth of December", value="Tenth of December",variable=book_selected)
    book1.grid(row=3,column=4,padx=10,pady=10)
    book1 = Radiobutton(issue_screen, text="The Secret", value="The Secret",variable=book_selected)
    book1.grid(row=4,column=4,padx=10,pady=10)
    book1 = Radiobutton(issue_screen, text="Haunted", value="Haunted",variable=book_selected)
    book1.grid(row=5,column=4,padx=10,pady=10)
    book1 = Radiobutton(issue_screen, text="How I live Now ", value="How I live Now ",variable=book_selected)
    book1.grid(row=6,column=4,padx=10,pady=10)

    button1 = Button(issue_screen, text="Issue Now", command=IssueNow)
    button1.grid(row=7,column=3,padx=10,pady=10)

    issue_screen.mainloop()


def return1():
    global return1_screen
    return1_screen = Tk()
    return1_screen.geometry("700x500")
    return1_screen.title("Return Book")
    return1_screen.configure(bg='red')

    label0 = Label(return1_screen, text="Return Book Window", bg="black", fg="white")
    label0.grid(column=3, padx=10, pady=10)

    ReturnName = Label(return1_screen, text="Name Of Student : ")
    ReturnName.grid(row=1,column=1,padx=10,pady=10)
    name = Entry(return1_screen)
    name.grid(row=1,column=2,padx=10,pady=10)

    query1_label = Button(return1_screen, text="Check in Database",command=lambda : query2(name.get()))
    query1_label.grid(row=2,column=2,padx=10)

    def query2(name):
        conn = sqlite3.connect('library.db')
        c = conn.cursor()


        c.execute("SELECT * FROM issue WHERE Name= ?",(name,))
        rows = c.fetchall()

        print_records = ''
        for row in rows:
            print_records += str(row) + "\n"

        for row in rows:
            returndate=row[3]


        querylabel = Label(return1_screen, text=print_records)

        querylabel.grid(row=3,column=2,padx=10,pady=10)

        Bill2 = Button(return1_screen, text="Bill", command=lambda: bill(returndate))
        Bill2.grid(row=5, column=2, padx=10, pady=10)

        delete_record = Button(return1_screen, text="Delete Record", command=lambda: delete_funtion(name))
        delete_record.grid(row=7, column=2, padx=10, pady=10)

        conn.commit()


        conn.close()

    def delete_funtion(name):
        conn = sqlite3.connect('library.db')
        c = conn.cursor()

        c.execute("DELETE from issue WHERE Name =?",(name,))


        conn.commit()

        conn.close()
        messagebox.showinfo("Records", "Records Deleted")

    def bill(returndate):
        issuedate=datetime.today()
        #issuedate = datetime.strptime(today, "%Y-%m-%d")
        returndate=datetime.strptime(returndate,"%Y-%m-%d")
        sum = (issuedate-returndate).days
        bill1=sum*2
        if sum < 0:
            querylabel1 = Label(return1_screen, text="No extra charge")

            querylabel1.grid(row=6, column=2, padx=10, pady=10)

        else:
            querylabel2 = Label(return1_screen, text=bill1)

            querylabel2.grid(row=6, column=2, padx=10, pady=10)



    return1_screen.mainloop()

def query():
    global query2
    query2 = Tk()
    query2.geometry("700x500")
    query2.title("All Records")
    query2.configure(bg='red')

    label0 = Label(query2, text="All Records", bg="black", fg="white")
    label0.grid(column=3, padx=10, pady=10)

    conn = sqlite3.connect('library.db')
    c = conn.cursor()

    c.execute("SELECT * FROM issue")
    records = c.fetchall()

    conn.commit()

    conn.close()
    print_records=''
    for record in records:
        print_records += str(record[0]) + " "  + str(record[1]) + " " + str(record[2]) + " " + str(record[3]) + " " + str(record[4]) + "\n"


    query1_label = Label(query2,text=print_records)
    query1_label.grid(row=2,column=3,padx=10,pady=10)


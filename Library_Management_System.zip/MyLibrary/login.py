from tkinter import *
from final import *

tkWindow = Tk()
tkWindow.geometry('500x300')
tkWindow.title('Library Management System')
label0= Label(tkWindow,text="LIBRARY MANAGEMENT SYSTEM",bg="black",fg="white")
label0.grid(column=1, padx=10, pady=10)
tkWindow.configure(bg='RED')

#username label and text entry box
nameLabel = Label(tkWindow, text="Enter your Name :",bg='blue')

name=StringVar()
nameEntry = Entry(tkWindow, textvariable=name)


#password label and password entry box
idLabel = Label(tkWindow,text="Enter Your Id : ", bg='blue')
id=StringVar()
idEntry = Entry(tkWindow, textvariable=id)



#login button
loginButton = Button(tkWindow, text="Login", command=lambda : student(name.get(), id.get()))

nameLabel.grid(row=1,column=0, sticky=W, padx=10, pady=10)
idLabel.grid(row=2,column=0, sticky=W, padx=10, pady=10)
nameEntry.grid(row=1,column=1, sticky=W, padx=10, pady=10)
idEntry.grid(row=2,column=1, sticky=W, padx=10, pady=10)
loginButton.grid(row=4,column=1, sticky=W, padx=10, pady=10)
tkWindow.mainloop()